package com.techacademy.service;

public class CreateDepartmentService {
}
