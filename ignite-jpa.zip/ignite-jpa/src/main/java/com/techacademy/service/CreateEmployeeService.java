package com.techacademy.service;

import com.techacademy.model.Departments;
import com.techacademy.model.Employees;
import com.techacademy.repository.DepartmentRepository;
import com.techacademy.repository.EmployeeRepository;
import com.techacademy.request.EmployeeRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Service
public class CreateEmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Transactional("igniteTransactionManager")
    public Employees createEmployee(EmployeeRequest employeeRequest){
        Departments departments = departmentRepository.findById(employeeRequest.getDepartmentId()).orElseGet(null);
        if(departments==null && Objects.nonNull(employeeRequest.getDepartmentName())){
            departments = new Departments();
            departments.setDeptNo(employeeRequest.getDepartmentId());
            departments.setDeptName(employeeRequest.getDepartmentName());
            departments = departmentRepository.save(departments.getDeptNo(),departments);
        }
        if(departments==null){
            throw new RuntimeException();
        }
        Employees employee = new Employees();
        employee.setBirthDate(employeeRequest.getBirthDate());
        employee.setFirstName(employeeRequest.getFirstName());
        employee.setGender(emp);

    }


}
