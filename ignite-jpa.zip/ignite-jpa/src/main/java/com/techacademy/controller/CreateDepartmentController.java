package com.techacademy.controller;

public class CreateDepartmentController {
}
