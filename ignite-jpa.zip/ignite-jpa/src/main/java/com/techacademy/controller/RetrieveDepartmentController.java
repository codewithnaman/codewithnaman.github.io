package com.techacademy.controller;

public class RetrieveDepartmentController {
}
