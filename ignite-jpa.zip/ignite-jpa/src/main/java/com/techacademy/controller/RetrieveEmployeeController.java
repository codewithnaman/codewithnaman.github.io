package com.techacademy.controller;

import com.techacademy.model.Employees;
import com.techacademy.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class RetrieveEmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/employee/{id}")
    public Employees getEmployeeDetails(@PathVariable("id") Integer id){
        return  employeeRepository.findById(id).orElseGet(null);
    }

    @GetMapping("/employee")
    public Map<String,Object> getAllEmployeesDetails(){
        Map<String,Object> response = new HashMap<>();
        List<Employees> employeesList = new ArrayList<>();
        for (Employees employee:employeeRepository.findAll()) {
            employeesList.add(employee);
        }
        response.put("employees",employeesList);
        response.put("count",employeesList.size());
        return response;
    }
}
