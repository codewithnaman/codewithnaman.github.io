package com.techacademy.controller;

import com.techacademy.model.Employees;
import com.techacademy.request.EmployeeRequest;
import com.techacademy.service.CreateEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateEmployeeController {

    @Autowired
    private CreateEmployeeService createEmployeeService;

    @PostMapping("/employee")
    private Employees createEmployees(@RequestBody EmployeeRequest employeeRequest){
        return createEmployeeService.createEmployee(employeeRequest);
    }
}
