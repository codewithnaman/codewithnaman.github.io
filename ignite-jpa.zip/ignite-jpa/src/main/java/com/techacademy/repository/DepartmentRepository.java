package com.techacademy.repository;

import com.techacademy.model.Departments;
import org.apache.ignite.springdata20.repository.IgniteRepository;
import org.apache.ignite.springdata20.repository.config.RepositoryConfig;

@RepositoryConfig(cacheName = "DepartmentsCache")
public interface DepartmentRepository extends IgniteRepository<Departments,String> {

}
