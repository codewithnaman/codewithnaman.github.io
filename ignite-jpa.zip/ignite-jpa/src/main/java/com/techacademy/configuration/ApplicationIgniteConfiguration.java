package com.techacademy.configuration;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.springdata20.repository.config.EnableIgniteRepositories;
import org.apache.ignite.transactions.spring.SpringTransactionManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableIgniteRepositories(basePackages = {"com.techacademy.repository"})
public class ApplicationIgniteConfiguration {

    @Bean("igniteInstance")
    public Ignite startIgniteForDataBaseService() {
        Ignite ignite = Ignition.start("META-INF/EmployeeCluster-client.xml");
       // ignite.cache("EmployeesCache").loadCache(null);
        return ignite;
    }

    @Bean("igniteTransactionManager")
    public SpringTransactionManager createSpringTransactionManager(){
        SpringTransactionManager springTransactionManager = new SpringTransactionManager();
        springTransactionManager.setConfigurationPath("META-INF/EmployeeCluster-client.xml");
        return springTransactionManager;
    }


}
